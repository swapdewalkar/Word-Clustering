from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.corpus import wordnet
import os
import re
import math
from scipy import spatial
import numpy as np
import pprint
import sklearn.cluster
from sklearn.cluster import spectral_clustering


def SpecialCharacters(word):
	if len(word)<3:
		return 1
	return 0     

inp_stop=open('data/stopwords.txt','r+') #read stopword from file
stopwords=eval(inp_stop.read())
# print stopwords


#Intialization
id=-1
i=0
directory="d"
II={}
Document_TF_Count={}
Documents=os.listdir(directory)


for Document in Documents:
	if i<3:
		i=i+1
	else:
		break
	f=open(directory+"/"+Document,'r');
	c=f.read()
	# c=f.read().split('\n')
	f.close();
	# id=c[4].replace('DOC ID:','')
	id=id+1
	# content=c[5].replace('CONTENT:','')
	print c
	content=c
	words=word_tokenize(str(content))
	lower_words=[x.lower() for x in words if not SpecialCharacters(x)]
	upper_words=[x for x in words if x.upper()==x and not SpecialCharacters(x)]
	words=[]
	words=lower_words+upper_words
	WordCount1={}
	#	
	for w in words:
		# if word in stopwords:
		#Term Frequency 
		if w in WordCount1:
			WordCount1[w]=WordCount1[w]+1
		else:
			WordCount1[w]=1
		#Inverted Index	
		if w in II:
			if id not in II[w]:
				II[w].append(id)
		else:
			II[w]=[]
			II[w].append(id)

	Document_TF_Count[id]=WordCount1

#Assign Term Frequency as Zero
vocab=II.keys()
for v in vocab:
	for key in Document_TF_Count:
		if v not in Document_TF_Count[key]:
			Document_TF_Count[key][v]=0


##Stemming#
stemmer=PorterStemmer()
l=len(vocab)
for key in Document_TF_Count:
	for t1 in range(l):
		for t2 in range(t1+1,l):
			v1=vocab[t1]
			v2=vocab[t2]
			stem1=stemmer.stem(v1)
			stem2=stemmer.stem(v2)

			tc1=Document_TF_Count[key][v1]
			tc2=Document_TF_Count[key][v2]	
			if tc1>0 and tc2>0 and v1!=v2 and stem1==stem2 and v1.upper()!=v2 and v2.upper()!=v1:
			#terms should exists in the same document not be equal, 
			#even upper or lower case should not be equal but stem should be			
				# print stem1
				# print stem2
				Document_TF_Count[key][v1]=tc1+1
				Document_TF_Count[key][v2]=tc1+1
# print Document_TF_Count
#Calculate TF-IDF
#print Document_TF_Count.keys()
term_vector={}
for v in vocab:
	idf=math.log((float(id+1)/len(II[v])),10)
	array=[]
	for key in Document_TF_Count:
		k=int(key)
		array+=[Document_TF_Count[key][v]*idf]
	term_vector[v]=array

pprint.pprint(term_vector)
print "++++++++++++++++++"
#Update TF-IDF using TMI
def sim_f(word1, word2):
	if word1==word2:
		return 0
	max_value=0.0
	wordFromList1 = wordnet.synsets(word1)
	wordFromList2 = wordnet.synsets(word2)
	for wl1 in wordFromList1:
		for wl2 in wordFromList2:
			p=wl1.wup_similarity(wl2)
			if max_value < p: 
				max_value = p
	return max_value

sim={}
for term1 in term_vector:
	sim[term1]={}
	for term2 in term_vector:
		sim[term1][term2]=sim_f(term1,term2)

print "++++++++++++++++++"
for term in term_vector:
 	l=len(term_vector[term])
 	#~ print term
 	for i in range(l):
		sumation=0
		for v in vocab:
			sumation+=term_vector[v][i]*sim[term][v]	
		term_vector[term][i]+=sumation		

pprint.pprint(term_vector)

Matrix={}
for tv1 in term_vector:
	Matrix[tv1]={}
	for tv2 in term_vector:
		Matrix[tv1][tv2] =1- spatial.distance.cosine(term_vector[tv1],term_vector[tv2])

Distance_Matrix=np.array(Matrix)
print Distance_Matrix

#~ from sklearn.cluster import AgglomerativeClustering
#~ agg = AgglomerativeClustering(n_clusters=5, affinity='precomputed')
#~ agg.fit_predict(Distance_Matrix)
i=0
l=len(vocab)
w, h = 8, 5;
DM = [[0 for x in range(l)] for y in range(l)]
for l1 in Matrix:
	j=0
	for l2 in Matrix[l1]:
		DM[i][j]=Matrix[l1][l2]
		j=j+1
	i=i+1	
print DM
vocab=np.asarray(vocab)	

from mcl_clustering import mcl


#~ affprop = sklearn.cluster.AffinityPropagation(preference=-50,affinity="precomputed", damping=0.5)
#~ affprop = sklearn.cluster.AffinityPropagation(preference=-565,affinity="euclidean",convergence_iter=5, damping=0.5)
#~ affprop.fit(DM)
#~ count=0
#~ for cluster_id in np.unique(affprop.labels_):
    #~ exemplar = vocab[affprop.cluster_centers_indices_[cluster_id]]
    #~ cluster = np.unique(vocab[np.nonzero(affprop.labels_==cluster_id)])
    #~ cluster_str = ", ".join(cluster)
    #~ print(cluster_str)
    #~ count=count+1
#~ print count

#~ import matplotlib.pyplot as plt

#~ from sklearn.feature_extraction import image
#~ from sklearn.cluster import spectral_clustering

#~ img=100*np.array(DM)
#~ print "++++++++++++++++++++++++",vocab,"++++++++++++++++++"
#~ # We use a mask that limits to the foreground: the problem that we are
#~ # interested in here is not separating the objects from the background,
#~ # but separating them one from the other.
#~ mask = img.astype(bool)

#~ img = img.astype(float)
#~ img += 1 + 0.2 * np.random.randn(*img.shape)

#~ # Convert the image into a graph with the value of the gradient on the
#~ # edges.
#~ graph = image.img_to_graph(img, mask=mask)
#~ print img
#~ print "======================="
#~ print graph
#~ # Take a decreasing function of the gradient: we take it weakly
#~ # dependent from the gradient the segmentation is close to a voronoi
#~ graph.data = np.exp(-graph.data / graph.data.std())

#~ # Force the solver to be arpack, since amg is numerically
#~ # unstable on this example
#~ labels = spectral_clustering(graph, n_clusters=4, eigen_solver='arpack')
#~ label_im = -np.ones(mask.shape)
#~ label_im[mask] = labels

#~ plt.matshow(img)
#~ plt.matshow(label_im)

#~ plt.show()
